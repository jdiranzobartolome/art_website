const jwt = require('jsonwebtoken');
const config = require('config');

module.exports = function(req, res, next) {
    // When we send a request to a protected route, we will need to send the token on the header
    // Get token from header
   const token = req.header('x-auth-token');

   // Check if not token
   if(!token) {
       // The 401 error means "no authorized"
       return res.status(401).json({ msg: 'No token, authorization denied' });
   }

   // Verify token
   try {
      const decoded = jwt.verify(token, config.get('jwtSecret'));
      // The token has the user in the payload so we get it 
      req.user = decoded.user;
      next(); 
   } catch(err) {
      res.status(401).json({ msg: 'Token is not valid' });
   }
}